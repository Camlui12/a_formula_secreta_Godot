class_name GuardCaptureState
extends State

var is_close_enough: bool = false

func enter() -> void:
	var guard = entity
	guard.velocity = Vector2.ZERO
	is_close_enough = false
	
	if guard.vision_pivot:
		guard.vision_pivot.hide()
		
	if guard.target:
		guard.target.velocity = Vector2.ZERO
		var player_sm = guard.target.get_node_or_null("StateMachine")
		if player_sm:
			player_sm.process_mode = Node.PROCESS_MODE_DISABLED
			
		if guard.target.has_node("AnimatedSprite2D"):
			guard.target.get_node("AnimatedSprite2D").stop()

func physics_update(_delta: float) -> void:
	var guard = entity
	
	if guard.target and not is_close_enough:
		var distance = guard.global_position.distance_to(guard.target.global_position)
		var dir = guard.global_position.direction_to(guard.target.global_position)
		
		if distance > 18.0:
			guard.velocity = dir * guard.SPEED
			_update_animation(dir, "walk")
		else:
			guard.velocity = Vector2.ZERO
			is_close_enough = true
			_update_animation(dir, "idle")

			if guard.target.has_method("take_damage"):
				guard.target.take_damage(2)

			if guard.target.current_health > 0:
				transitioned.emit(self, &"wait")
				
	guard.move_and_slide()

func _update_animation(dir: Vector2, action: String) -> void:
	if not sprite_anim: 
		return
		
	if abs(dir.x) > abs(dir.y):
		if dir.x > 0:
			sprite_anim.play(action + "_right")
		else:
			sprite_anim.play(action + "_left")
	else:
		if dir.y > 0:
			sprite_anim.play(action + "_down")
		else:
			sprite_anim.play(action + "_up")
