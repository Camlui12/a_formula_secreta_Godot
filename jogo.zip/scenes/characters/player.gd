class_name Player
extends CharacterBody2D

@export var speed: float = 60.0
@export var max_health: int = 6

var facing_direction: Vector2 = Vector2.DOWN
var current_health: int = max_health
var is_invulnerable := false

signal health_changed(current_health: int)


func get_movement_input() -> Vector2:
	var direction := Input.get_vector(
		"move_left",
		"move_right",
		"move_up",
		"move_down"
	)

	if direction == Vector2.ZERO:
		return Vector2.ZERO

	if abs(direction.x) >= abs(direction.y):
		direction = Vector2(sign(direction.x), 0.0)
	else:
		direction = Vector2(0.0, sign(direction.y))

	facing_direction = direction
	return direction


func get_cardinal_direction() -> String:
	match facing_direction:
		Vector2.UP: return "up"
		Vector2.DOWN: return "down"
		Vector2.LEFT: return "left"
		Vector2.RIGHT: return "right"
		_: return "down"


func take_damage(amount: int) -> void:
	if is_invulnerable or current_health <= 0:
		return

	current_health = max(0, current_health - amount)
	health_changed.emit(current_health)

	if current_health > 0:
		is_invulnerable = true
		await get_tree().create_timer(1.2).timeout
		is_invulnerable = false
