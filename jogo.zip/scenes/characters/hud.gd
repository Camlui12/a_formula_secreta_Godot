extends CanvasLayer

@onready var player: Player = get_parent()
@onready var hearts = [
	$HeartContainer/Slot1/Heart1,
	$HeartContainer/Slot2/Heart2,
	$HeartContainer/Slot3/Heart3
]

func _ready() -> void:
	player.health_changed.connect(update_hearts)
	update_hearts(player.current_health)

func update_hearts(current_health: int) -> void:
	for i in range(hearts.size()):
		var heart_health := current_health - i * 2

		if heart_health >= 2:
			hearts[i].animation = &"full"
		elif heart_health == 1:
			hearts[i].animation = &"half"
		else:
			hearts[i].animation = &"empty"
