class_name GuardPatrolState
extends State

const WALK_TIME: float = 3.0
var timer: float = 0.0

func enter() -> void:
	timer = WALK_TIME
	play_walk_animation()

func physics_update(delta: float) -> void:
	var guard = entity

	if guard.is_on_wall():
		guard.flip_direction()
		timer = WALK_TIME
		play_walk_animation()
		return

	timer -= delta
	if timer <= 0.0:
		transitioned.emit(self, &"wait")
		return

	guard.velocity = Vector2(guard.direction * guard.SPEED, 0.0)
	guard.move_and_slide()
	play_walk_animation()

func play_walk_animation() -> void:
	if sprite_anim and entity:
		sprite_anim.play("walk_" + entity.get_cardinal_direction())
