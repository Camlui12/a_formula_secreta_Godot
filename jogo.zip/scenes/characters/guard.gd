class_name Guard
extends CharacterBody2D

const SPEED: float = 60.0

var direction: float = 1.0
var target: Node2D = null

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var vision_pivot: Node2D = $VisionPivot
@onready var vision_area: Area2D = $VisionPivot/Area2D
@onready var state_machine: StateMachine = $StateMachine

func _ready() -> void:
	vision_area.body_entered.connect(_on_vision_area_body_entered)
	if sprite:
		sprite.flip_h = false
	update_vision_direction()

func flip_direction() -> void:
	direction *= -1.0
	update_vision_direction()

func update_vision_direction() -> void:
	if not vision_pivot:
		return
		
	# Gira o pivô completo com o sprite e a colisão juntos
	if direction > 0.0:
		vision_pivot.rotation_degrees = 0.0
	else:
		vision_pivot.rotation_degrees = 180.0

func get_cardinal_direction() -> String:
	if direction > 0.0:
		return "right"
	return "left"

func _on_vision_area_body_entered(body: Node2D) -> void:
	if body == self:
		return

	if body.name == "Player" or body.is_in_group("Player"):
		if state_machine.current_state and state_machine.current_state.name == "Capture":
			return
			
		target = body
		state_machine.on_child_transitioned(state_machine.current_state, &"capture")
