extends CanvasLayer

@onready var color_rect: ColorRect = $ColorRect
@onready var audio_player: AudioStreamPlayer = $AudioStreamPlayer
@onready var animation_player: AnimationPlayer = $AnimationPlayer

func _ready() -> void:
	color_rect.modulate.a = 0.0
	color_rect.hide()

func trigger_game_over() -> void:
	color_rect.show()
	
	if audio_player.stream:
		audio_player.play()
		
	animation_player.play("fade_out")
	await animation_player.animation_finished
	
	DialogueManager.show_auto_dialogue("Niccolo foi preso.")
	await DialogueManager.dialogue_finished
	
	await get_tree().create_timer(1.0).timeout
	
	get_tree().change_scene_to_file("res://scenes/levels/intro.tscn")
	
	animation_player.play("fade_in")
	await animation_player.animation_finished
	
	color_rect.hide()
