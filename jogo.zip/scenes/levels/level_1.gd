extends Node2D

@onready var player = $Player

var intro_lines: Array[String] = [
	"Brescia, Itália, 1512.",
	"Um menino corre entre chamas e espadas.",
	"Seu nome é Niccolò Fontana.",
	"O mundo logo o chamará de Tartaglia."
]

func _ready() -> void:
	player.set_physics_process(false)
	
	await get_tree().create_timer(2.0).timeout
	
	DialogueManager.show_custom_dialogue(intro_lines)
	await DialogueManager.dialogue_finished
	
	player.set_physics_process(true)
