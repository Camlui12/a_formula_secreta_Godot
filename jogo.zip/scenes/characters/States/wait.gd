class_name GuardWaitState
extends State

const WAIT_TIME: float = 1.5
var timer: float = 0.0

func enter() -> void:
	timer = WAIT_TIME
	entity.velocity = Vector2.ZERO
	if sprite_anim and entity:
		sprite_anim.play("idle_" + entity.get_cardinal_direction())

func physics_update(delta: float) -> void:
	timer -= delta
	if timer <= 0.0:
		var guard = entity
		guard.flip_direction()
		transitioned.emit(self, &"patrol")
