class_name WalkState
extends State

func physics_update(_delta: float) -> void:
	var player := entity as Player
	var dir := player.get_movement_input()
	
	if dir == Vector2.ZERO:
		transitioned.emit(self, &"idle")
		return
	
	player.velocity = dir.normalized() * player.speed
	player.move_and_slide()
	
	sprite_anim.play("walk_" + player.get_cardinal_direction())
