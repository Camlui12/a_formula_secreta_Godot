class_name IdleState
extends State

func enter() -> void:
	entity.velocity = Vector2.ZERO
	sprite_anim.play("idle_" + (entity as Player).get_cardinal_direction())

func physics_update(_delta: float) -> void:
	var dir := (entity as Player).get_movement_input()
	if dir != Vector2.ZERO:
		transitioned.emit(self, &"walk")
